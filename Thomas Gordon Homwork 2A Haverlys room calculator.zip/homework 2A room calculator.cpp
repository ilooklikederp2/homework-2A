////////////////////////////////////////////////////
//Name: Thomas Gordon							  // 
//Date: 9-17-17                                   // 
//Assignment: Homework 2A Haverlys room calculator//
//Class: intro to computer programing (c++)       //
////////////////////////////////////////////////////
//this program is ment to calculate the area of a...
//rectangul, square, and circular room 
//using input and output with a guided menu at the beginning
//also it is meant to give an error messege when 1,2,3, or 4 are
//not typed for the menu input

//header files and librarys
#include<iostream>
using namespace std;

//beginning of function
int main()
{
	//this is the start of the menu:
	cout << "Haverly's Room Calculator : " << endl << endl;
	cout << "************************" << endl << endl;
	cout << "1.	Square Room" << endl;
	cout << "2.	Rectangular Room" << endl;
	cout << "3.	circle Room" << endl;
	cout << "4.	Quit" << endl << endl;

	cout << "Please enter a menu item(1 - 4) >" << endl;
	//this is the end of the menu

	//asigns numbers to the menu items
	float menu_item;
	float square = 1, rectangle = 2, circle = 3, quit = 4;

	cin >> menu_item; //gets user input

					  //this part calculates for the area of a square room
	if (menu_item == 1)
	{
		cout << "Please enter the width of the room " << endl;
		float width = 1;
		cin >> width;
		cout << "the area of the room is " << width * 2 << endl;
	}
	//this part lets you calculate the area for the rectangle room
	else if (menu_item == 2)
	{
		cout << "Please enter the length and width of the room " << endl;
		float width = 1;
		float length = 1;
		cin >> length >> width;
		cout << "The area of the room is " << length * width << endl;
	}
	//this part lets you calculate the area for the circle room
	else if (menu_item == 3)
	{
		double radius;
		cout << "Please enter the radius of the room " << endl;
		cin >> radius;
		double pi = 3.14159;
		double area_circle = pi * pow(radius, 2.0);
		cout << "the area of the room is " << area_circle << endl;
	}
	//last part of the if else if statement 
	//that lets you exit the program smoothly 
	else if (menu_item == 4)
	{
		cout << "thank you for using Haverly's Room Calculator goodbye ;) " << endl;
	}
	else (menu_item != 1, 2, 3, 4); // could not get this to work
	
	system("pause");
}


